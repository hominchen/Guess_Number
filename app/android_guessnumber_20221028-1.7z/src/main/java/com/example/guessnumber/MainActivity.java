package com.example.guessnumber;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void replay(View view) {
    }

    public void send(View view) {
    }

    public void clear(View view) {
    }

    public void back(View view) {
    }

    public void inputNumber(View view) {
    }
}